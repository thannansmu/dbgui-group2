function addCar() {

  var addButton = document.getElementById("add-button");
addButton.addEventListener("click", addCar);

  // Get the value of the new car input
  var newCar = document.getElementById("new-car").value;
  
  // Create a new option element for the drop-down selection
  var newOption = document.createElement("option");
  newOption.text = newCar;
  
  // Add the new option to the drop-down selection
  var carDropdown = document.getElementById("car-dropdown");
  carDropdown.add(newOption);
}



